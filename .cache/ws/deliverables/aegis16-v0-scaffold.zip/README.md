# Aegis-16 — Mech Royale bot (Builders Buildathon 2026)

**Team:** farebi · **Member:** Hrudayangam Mehta

A bot for the Builders "Mech Royale" track (protocol `mechfight/1`): it pilots one mech in a 16-mech battle
royale on the OSU campus map. Score is placement (`16 - place`), so the design is survival-first.

- Language: plain JavaScript (ES modules), zero dependencies, run with Bun 1.4.4 (pinned in the `Dockerfile`).
- `bot.js` is the entry point: the stdin/stdout protocol loop with fail-safes (a fault in any module falls
  back to a simple zone-and-shoot policy, so the mech never stands still).

## Run the conformance check

From the official kit folder (`mechfight-kit/`):

```sh
python3 check/check.py -- bun /path/to/this/repo/bot.js
docker build -t aegis16 /path/to/this/repo
python3 check/check.py --map-dir /arena -- docker run --rm -i --network none --cpus 1 --memory 512m \
  --read-only --tmpfs /tmp:rw,size=64m --user 65534:65534 -v "$PWD/arena:/arena:ro" aegis16
```

Built with AI assistance (allowed by the track rules); all code in this repository is original to this team.
